import tkinter as tk
from tkinter import ttk, messagebox
from tkcalendar import DateEntry
import datetime

# Dummy patient/doctor names instead of IDs
patients = ["John Doe", "Alice Smith", "Bob Johnson"]
doctors = ["Dr. Brown", "Dr. Taylor", "Dr. Lee"]

appointments = []  # Store appointments here

def update_status():
    now = datetime.datetime.now()
    for appt in appointments:
        appt_time = datetime.datetime.strptime(appt["datetime"], "%Y-%m-%d %H:%M")
        if appt_time < now:
            appt["status"] = "Completed"
        else:
            appt["status"] = "Upcoming"

def open_appointment_management():
    window = tk.Toplevel()
    window.title("Appointment Management")
    window.geometry("600x500")

    # Patient Dropdown
    tk.Label(window, text="Select Patient").pack()
    patient_combo = ttk.Combobox(window, values=patients)
    patient_combo.pack()

    # Doctor Dropdown
    tk.Label(window, text="Select Doctor").pack()
    doctor_combo = ttk.Combobox(window, values=doctors)
    doctor_combo.pack()

    # Date Picker
    tk.Label(window, text="Select Date").pack()
    date_entry = DateEntry(window, width=18, background='darkblue', foreground='white', borderwidth=2)
    date_entry.pack()

    # Time Dropdown
    tk.Label(window, text="Select Time").pack()
    time_combo = ttk.Combobox(window, values=[f"{h:02d}:00" for h in range(9, 18)])
    time_combo.pack()

    # Add Appointment
    def add_appointment():
        name = patient_combo.get()
        doc = doctor_combo.get()
        date = date_entry.get_date()
        time = time_combo.get()
        if not name or not doc or not time:
            messagebox.showwarning("Missing", "Please fill all fields.")
            return
        dt_str = f"{date} {time}"
        appointments.append({"patient": name, "doctor": doc, "datetime": dt_str, "status": "Upcoming"})
        update_status()
        refresh_table()

    tk.Button(window, text="Add Appointment", command=add_appointment).pack(pady=10)

    # Search bar
    search_var = tk.StringVar()
    tk.Entry(window, textvariable=search_var).pack()
    def search():
        keyword = search_var.get().lower()
        results = [a for a in appointments if keyword in a["patient"].lower() or keyword in a["doctor"].lower()]
        refresh_table(results)
    tk.Button(window, text="Search", command=search).pack()

    # Appointment table
    table = ttk.Treeview(window, columns=("patient", "doctor", "datetime", "status"), show="headings")
    for col in table["columns"]:
        table.heading(col, text=col.capitalize())
    table.pack(fill=tk.BOTH, expand=True, pady=10)

    def refresh_table(data=None):
        for row in table.get_children():
            table.delete(row)
        update_status()
        for appt in data or appointments:
            table.insert("", tk.END, values=(appt["patient"], appt["doctor"], appt["datetime"], appt["status"]))

    refresh_table()
