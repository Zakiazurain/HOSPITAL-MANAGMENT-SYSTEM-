import tkinter as tk
from tkinter import messagebox
import mysql.connector


from dashboard import open_dashboard  # ✅ Make sure this file exists


def login():
    username = username_entry.get()
    password = password_entry.get()

    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="admin",  # Use your actual MySQL password
            database="doctor_management_system"
        )
        cursor = conn.cursor()
        query = "SELECT * FROM admin WHERE username = %s AND password = %s"
        cursor.execute(query, (username, password))
        result = cursor.fetchone()

        if result:
            messagebox.showinfo("Login Success", f"Welcome, {username}!")
            root.withdraw()  # ✅ Hide login instead of destroy
            open_dashboard(username)  # ✅ Open dashboard
        else:
            messagebox.showerror("Login Failed", "Invalid username or password")

        conn.close()

    except mysql.connector.Error as err:
        messagebox.showerror("Database Error", str(err))

# GUI window
root = tk.Tk()
root.title("Doctor Management System - Login")
root.geometry("300x200")

tk.Label(root, text="Username").pack(pady=5)
username_entry = tk.Entry(root)
username_entry.pack(pady=5)

tk.Label(root, text="Password").pack(pady=5)
password_entry = tk.Entry(root, show="*")
password_entry.pack(pady=5)

tk.Button(root, text="Login", command=login).pack(pady=10)

root.mainloop()
