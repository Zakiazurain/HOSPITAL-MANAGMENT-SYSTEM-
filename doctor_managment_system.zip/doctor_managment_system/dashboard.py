import tkinter as tk
from tkinter import messagebox
from doctor_management import open_doctor_management
from patientmanagement import open_patient_management  # Assuming this is your patient mgmt file
from appointment_management import open_appointment_management

def manage_appointments():
    messagebox.showinfo("Appointments", "Here you can manage appointments!")

def logout(dashboard):
    dashboard.destroy()
    messagebox.showinfo("Logout", "You have been logged out!")

def open_dashboard(username):
    dashboard = tk.Toplevel()
    dashboard.title("Doctor Management Dashboard")
    dashboard.geometry("500x400")
    dashboard.configure(bg="#f4f6f7")  # light gray background

    tk.Label(
        dashboard, 
        text=f"Welcome, {username}!", 
        font=("Segoe UI", 18, "bold"), 
        bg="#f4f6f7", 
        fg="#2c3e50"
    ).pack(pady=20)

    # Buttons inside the function and properly indented
    tk.Button(dashboard, text="Manage Doctors", width=25, height=2, bg="#3498db", fg="white", command=open_doctor_management).pack(pady=10)
    tk.Button(dashboard, text="Manage Patients", width=25, height=2, bg="#1abc9c", fg="white", command=open_patient_management).pack(pady=10)
    tk.Button(dashboard, text="Appointments", width=25, height=2, bg="#9b59b6", fg="white", command=open_appointment_management).pack(pady=10)
    tk.Button(dashboard, text="Logout", width=25, height=2, bg="#e74c3c", fg="white", command=lambda: logout(dashboard)).pack(pady=30)

# Example to run dashboard independently for testing:
if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()  # hide main window
    open_dashboard("AdminUser")
    root.mainloop()
