import mysql.connector

# Step 1: Connect to MySQL
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="admin",  # ← Replace with your MySQL password
    database="doctor_management_system"  # ← Make sure this matches your DB name
)

# Step 2: Create a cursor
cursor = conn.cursor()

# Step 3: Run a test query
cursor.execute("SELECT * FROM doctors")  # ← Make sure 'doctors' table exists

# Step 4: Fetch and print the data
for row in cursor.fetchall():
    print(row)

# Step 5: Close the connection
conn.close()
