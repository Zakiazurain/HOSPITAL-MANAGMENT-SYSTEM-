import tkinter as tk
from tkinter import messagebox, ttk
import mysql.connector
import difflib

def open_doctor_management():
    win = tk.Toplevel()
    win.title("Manage Doctors")
    win.geometry("700x500")
    win.configure(bg="#f0f2f5")

    # --- Entry Form ---
    tk.Label(win, text="Doctor Name", bg="#f0f2f5").grid(row=0, column=0, padx=10, pady=10)
    name_entry = tk.Entry(win)
    name_entry.grid(row=0, column=1, padx=10)

    tk.Label(win, text="Specialty", bg="#f0f2f5").grid(row=1, column=0, padx=10, pady=10)
    spec_entry = tk.Entry(win)
    spec_entry.grid(row=1, column=1, padx=10)

    # --- Search Bar ---
    tk.Label(win, text="Search Doctor by Name", bg="#f0f2f5").grid(row=2, column=0, padx=10, pady=5, sticky="w")
    search_entry = tk.Entry(win)
    search_entry.grid(row=2, column=1, padx=10, pady=5, sticky="ew")

    # --- Table View with Scrollbar ---
    table_frame = tk.Frame(win)
    table_frame.grid(row=5, column=0, columnspan=2, padx=10, pady=10, sticky="nsew")

    scrollbar = tk.Scrollbar(table_frame)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    doctor_table = ttk.Treeview(table_frame, columns=("ID", "Name", "Specialty"), show="headings", yscrollcommand=scrollbar.set)
    scrollbar.config(command=doctor_table.yview)

    doctor_table.heading("ID", text="ID")
    doctor_table.heading("Name", text="Name")
    doctor_table.heading("Specialty", text="Specialty")
    doctor_table.pack(fill=tk.BOTH, expand=True)

    # --- Backend Functions ---
    def add_doctor():
        name = name_entry.get()
        spec = spec_entry.get()

        if not name or not spec:
            messagebox.showwarning("Input Error", "All fields are required")
            return

        try:
            conn = mysql.connector.connect(host="localhost", user="root", password="admin", database="doctor_management_system")
            cursor = conn.cursor()
            cursor.execute("INSERT INTO doctors (name, specialty) VALUES (%s, %s)", (name, spec))
            conn.commit()
            conn.close()

            messagebox.showinfo("Success", "Doctor added successfully!")
            name_entry.delete(0, tk.END)
            spec_entry.delete(0, tk.END)
            show_doctors()

        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", str(err))

    def delete_doctor():
        selected = doctor_table.selection()
        if not selected:
            messagebox.showwarning("No selection", "Please select a doctor to delete")
            return

        doctor_id = doctor_table.item(selected[0])['values'][0]

        try:
            conn = mysql.connector.connect(host="localhost", user="root", password="admin", database="doctor_management_system")
            cursor = conn.cursor()
            cursor.execute("DELETE FROM doctors WHERE doctor_id = %s", (doctor_id,))
            conn.commit()
            conn.close()

            messagebox.showinfo("Deleted", "Doctor removed successfully")
            show_doctors()

        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", str(err))

    def show_doctors():
        for row in doctor_table.get_children():
            doctor_table.delete(row)

        try:
            conn = mysql.connector.connect(host="localhost", user="root", password="admin", database="doctor_management_system")
            cursor = conn.cursor()
            cursor.execute("SELECT doctor_id, name, specialty FROM doctors")
            for row in cursor.fetchall():
                doctor_table.insert("", "end", values=row)
            conn.close()

        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", str(err))

    def search_doctors():
        keyword = search_entry.get().lower().strip()
        for row in doctor_table.get_children():
            doctor_table.delete(row)

        try:
            conn = mysql.connector.connect(host="localhost", user="root", password="admin", database="doctor_management_system")
            cursor = conn.cursor()
            cursor.execute("SELECT doctor_id, name, specialty FROM doctors")
            all_doctors = cursor.fetchall()
            conn.close()

            matches = []

            for row in all_doctors:
                doctor_name = row[1].lower()
                if keyword in doctor_name:
                    matches.append(row)
                else:
                    close_matches = difflib.get_close_matches(keyword, [doctor_name], n=1, cutoff=0.7)
                    if close_matches:
                        matches.append(row)

            if matches:
                for row in matches:
                    doctor_table.insert("", "end", values=row)
            else:
                messagebox.showinfo("Not Found", "Doctor not found.")

        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", str(err))

    # --- Buttons ---
    tk.Button(win, text="Add Doctor", bg="#27ae60", fg="white", command=add_doctor).grid(row=3, column=0, pady=10)
    tk.Button(win, text="Delete Selected", bg="#c0392b", fg="white", command=delete_doctor).grid(row=3, column=1, pady=10)
    tk.Button(win, text="Search", bg="#2980b9", fg="white", command=search_doctors).grid(row=4, column=1, sticky="e", padx=10, pady=5)
    tk.Button(win, text="Show All Doctors", bg="#16a085", fg="white", command=show_doctors).grid(row=4, column=0, sticky="w", padx=10, pady=5)

    # --- Back Button ---
    tk.Button(win, text="Back to Dashboard", bg="#7f8c8d", fg="white", command=win.destroy).grid(row=6, column=0, columnspan=2, pady=10)

    win.grid_rowconfigure(5, weight=1)
    win.grid_columnconfigure(1, weight=1)

    show_doctors()
