<?php
include 'db_connect.php'; // your DB connection file
?>

<!DOCTYPE html>
<html>
<head>
    <title>Appointment List</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
    <h2 class="mb-4">All Appointments</h2>

    <!-- Search / Filter Section -->
    <form method="GET" class="row mb-4">
        <div class="col-md-3">
            <input type="text" name="doctor" class="form-control" placeholder="Doctor name">
        </div>
        <div class="col-md-3">
            <input type="text" name="patient" class="form-control" placeholder="Patient name">
        </div>
        <div class="col-md-3">
            <select name="status" class="form-select">
                <option value="">-- Status --</option>
                <option value="Upcoming">Upcoming</option>
                <option value="Completed">Completed</option>
                <option value="Cancelled">Cancelled</option>
            </select>
        </div>
        <div class="col-md-3">
            <button class="btn btn-primary">Search</button>
        </div>
    </form>

    <!-- Appointment Table -->
    <table class="table table-bordered table-hover">
        <thead class="table-dark">
        <tr>
            <th>ID</th>
            <th>Patient</th>
            <th>Doctor</th>
            <th>Date</th>
            <th>Status</th>
            <th>Remarks</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $query = "SELECT 
                    a.*, 
                    p.name AS patient_name, 
                    d.name AS doctor_name 
                  FROM appointments a 
                  JOIN patients p ON a.patient_id = p.patient_id 
                  JOIN doctors d ON a.doctor_id = d.doctor_id 
                  WHERE 1";

        if (!empty($_GET['doctor'])) {
            $doctor = $_GET['doctor'];
            $query .= " AND d.name LIKE '%$doctor%'";
        }
        if (!empty($_GET['patient'])) {
            $patient = $_GET['patient'];
            $query .= " AND p.name LIKE '%$patient%'";
        }
        if (!empty($_GET['status'])) {
            $status = $_GET['status'];
            $query .= " AND a.status = '$status'";
        }

        $query .= " ORDER BY a.appointment_date DESC";

        $result = mysqli_query($conn, $query);
        while ($row = mysqli_fetch_assoc($result)) {
            $statusClass = match($row['status']) {
                'Upcoming' => 'primary',
                'Completed' => 'success',
                'Cancelled' => 'danger',
                default => 'secondary'
            };
            echo "<tr>
                    <td>{$row['appointment_id']}</td>
                    <td>{$row['patient_name']}</td>
                    <td>{$row['doctor_name']}</td>
                    <td>{$row['appointment_date']}</td>
                    <td><span class='badge bg-$statusClass'>{$row['status']}</span></td>
                    <td>{$row['remarks']}</td>
                  </tr>";
        }
        ?>
        </tbody>
    </table>
</div>
</body>
</html>
