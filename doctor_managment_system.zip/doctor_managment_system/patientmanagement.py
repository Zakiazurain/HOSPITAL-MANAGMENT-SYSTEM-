import tkinter as tk
from tkinter import messagebox, ttk
import mysql.connector
from difflib import SequenceMatcher

def open_patient_management():
    win = tk.Toplevel()
    win.title("Manage Patients")
    win.geometry("800x550")
    win.configure(bg="#f0f2f5")

    def similarity_ratio(a, b):
        return SequenceMatcher(None, a, b).ratio() * 100

    # --- Entry Form ---
    tk.Label(win, text="Patient Name", bg="#f0f2f5").grid(row=0, column=0, padx=10, pady=10, sticky="w")
    name_entry = tk.Entry(win)
    name_entry.grid(row=0, column=1, padx=10, pady=10, sticky="ew")

    tk.Label(win, text="Age", bg="#f0f2f5").grid(row=1, column=0, padx=10, pady=10, sticky="w")
    age_entry = tk.Entry(win)
    age_entry.grid(row=1, column=1, padx=10, pady=10, sticky="ew")

    def validate_age_input(P):
        return P.isdigit() or P == ""

    age_entry.configure(validate="key", validatecommand=(win.register(validate_age_input), "%P"))

    tk.Label(win, text="Gender", bg="#f0f2f5").grid(row=2, column=0, padx=10, pady=10, sticky="w")
    gender_combobox = ttk.Combobox(win, values=["Male", "Female", "Kid", "Baby", "Other"])
    gender_combobox.grid(row=2, column=1, padx=10, pady=10, sticky="ew")
    gender_combobox.set("Male")

    # --- Table View ---
    table_frame = tk.Frame(win)
    table_frame.grid(row=6, column=0, columnspan=3, padx=10, pady=10, sticky="nsew")

    scrollbar = tk.Scrollbar(table_frame)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    patient_table = ttk.Treeview(table_frame, columns=("ID", "Name", "Age", "Gender"), show="headings", yscrollcommand=scrollbar.set)
    scrollbar.config(command=patient_table.yview)

    for col in ("ID", "Name", "Age", "Gender"):
        patient_table.heading(col, text=col)

    patient_table.pack(fill=tk.BOTH, expand=True)

    def clear_fields():
        name_entry.delete(0, tk.END)
        age_entry.delete(0, tk.END)
        gender_combobox.set("Male")

    def show_patients():
        for row in patient_table.get_children():
            patient_table.delete(row)

        try:
            conn = mysql.connector.connect(host="localhost", user="root", password="admin", database="doctor_management_system")
            cursor = conn.cursor()
            cursor.execute("SELECT patient_id, name, age, gender FROM patients")
            for row in cursor.fetchall():
                patient_table.insert("", "end", values=row)
            conn.close()
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", str(err))

    def add_patient():
        name = name_entry.get().strip()
        age = age_entry.get().strip()
        gender = gender_combobox.get()

        if not name or not age or not gender:
            messagebox.showwarning("Input Error", "All fields are required")
            return

        try:
            conn = mysql.connector.connect(host="localhost", user="root", password="admin", database="doctor_management_system")
            cursor = conn.cursor()
            cursor.execute("INSERT INTO patients (name, age, gender) VALUES (%s, %s, %s)", (name, age, gender))
            conn.commit()
            conn.close()

            messagebox.showinfo("Success", "Patient added successfully!")
            clear_fields()
            show_patients()
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", str(err))

    def edit_patient():
        selected = patient_table.selection()
        if not selected:
            messagebox.showwarning("No selection", "Please select a patient to edit")
            return

        patient_id = patient_table.item(selected[0])['values'][0]
        name = name_entry.get().strip()
        age = age_entry.get().strip()
        gender = gender_combobox.get()

        if not name or not age or not gender:
            messagebox.showwarning("Input Error", "All fields are required")
            return

        try:
            conn = mysql.connector.connect(host="localhost", user="root", password="admin", database="doctor_management_system")
            cursor = conn.cursor()
            cursor.execute("UPDATE patients SET name=%s, age=%s, gender=%s WHERE patient_id=%s", (name, age, gender, patient_id))
            conn.commit()
            conn.close()

            messagebox.showinfo("Updated", "Patient details updated successfully")
            clear_fields()
            show_patients()
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", str(err))

    def delete_patient():
        selected = patient_table.selection()
        if not selected:
            messagebox.showwarning("No selection", "Please select a patient to delete")
            return

        patient_id = patient_table.item(selected[0])['values'][0]

        try:
            conn = mysql.connector.connect(host="localhost", user="root", password="admin", database="doctor_management_system")
            cursor = conn.cursor()
            cursor.execute("DELETE FROM patients WHERE patient_id = %s", (patient_id,))
            conn.commit()
            conn.close()

            messagebox.showinfo("Deleted", "Patient removed successfully")
            show_patients()
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", str(err))

    def search_patients():
        keyword = search_entry.get().lower().strip()
        for row in patient_table.get_children():
            patient_table.delete(row)

        try:
            conn = mysql.connector.connect(host="localhost", user="root", password="admin", database="doctor_management_system")
            cursor = conn.cursor()
            cursor.execute("SELECT patient_id, name, age, gender FROM patients")
            all_patients = cursor.fetchall()
            conn.close()

            matches = []

            for row in all_patients:
                patient_name = row[1].lower()
                ratio = similarity_ratio(keyword, patient_name)
                if keyword in patient_name or ratio > 70:
                    matches.append(row)

            if matches:
                for row in matches:
                    patient_table.insert("", "end", values=row)
            else:
                messagebox.showinfo("Not Found", "Patient not found.")
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", str(err))

    def fill_form_from_selection(event):
        selected = patient_table.selection()
        if selected:
            data = patient_table.item(selected[0])['values']
            name_entry.delete(0, tk.END)
            name_entry.insert(0, data[1])
            age_entry.delete(0, tk.END)
            age_entry.insert(0, data[2])
            gender_combobox.set(data[3])

    patient_table.bind("<<TreeviewSelect>>", fill_form_from_selection)

    # --- Search Bar ---
    search_frame = tk.Frame(win, bg="#f0f2f5")
    search_frame.grid(row=3, column=0, columnspan=2, padx=10, pady=5, sticky="ew")

    search_entry = tk.Entry(search_frame)
    search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
    tk.Button(search_frame, text="Search", bg="#2980b9", fg="white", command=search_patients).pack(side=tk.LEFT, padx=5)

    # --- Buttons ---
    btn_frame = tk.Frame(win, bg="#f0f2f5")
    btn_frame.grid(row=4, column=0, columnspan=3, pady=10)

    tk.Button(btn_frame, text="Add Patient", bg="#27ae60", fg="white", command=add_patient).grid(row=0, column=0, padx=5)
    tk.Button(btn_frame, text="Edit Selected", bg="#f39c12", fg="white", command=edit_patient).grid(row=0, column=1, padx=5)
    tk.Button(btn_frame, text="Delete Selected", bg="#c0392b", fg="white", command=delete_patient).grid(row=0, column=2, padx=5)
    tk.Button(btn_frame, text="Show All", bg="#16a085", fg="white", command=show_patients).grid(row=0, column=3, padx=5)
    tk.Button(btn_frame, text="Back to Dashboard", bg="#7f8c8d", fg="white", command=win.destroy).grid(row=0, column=4, padx=5)

    win.grid_rowconfigure(6, weight=1)
    win.grid_columnconfigure(1, weight=1)

    show_patients()
